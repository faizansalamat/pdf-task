package com.app.task.service;

import com.app.task.model.BankTransaction;
import jakarta.transaction.Transactional;
import org.springframework.data.domain.Page;

public interface ITransactionService {
    void saveTransaction(BankTransaction bankTransaction);

    // Method to update an existing transaction
    @Transactional
    void updateTransaction(BankTransaction transaction);

    Page<BankTransaction> findAllTransactions(int page, int pageSize);

    Page<BankTransaction> findAllTransactionsByCustomerId(int page, int pageSize, Long customerId);

    BankTransaction findTransactionById(Long id);

    Page<BankTransaction> searchTransactions(Long customerId, String searchTerm, int page, int pageSize);
}
