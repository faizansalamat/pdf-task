package com.app.task.util;

import com.app.task.model.BankTransaction;
import com.app.task.service.ITransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.core.io.ClassPathResource;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.time.LocalDateTime;
import java.util.List;

/**
 * This Job runs every minute to process pdf and store data in the DB.
 * @author Faizan Salamat
 */
@Component
public class PdfCronJob {

    @Autowired
    private ITransactionService service;

    @Scheduled(cron = "0 */1 * * * ?") // Runs
    public void processPdfFile() throws IOException {
        String filePath = new ClassPathResource("test-file.pdf").getFile().getAbsolutePath();
        try {
            List<BankTransaction> bankTransactions = FileUtil.parsePdf(filePath);
            bankTransactions.forEach(service::saveTransaction);
            System.out.println("PDF file processed successfully at " + LocalDateTime.now());
        } catch (Exception e) {
            System.err.println("Failed to process PDF file: " + e.getMessage());
        }
    }
}
