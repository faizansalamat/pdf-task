package com.app.task.service.Impl;

import com.app.task.model.BankTransaction;
import com.app.task.repository.TransactionRepository;
import com.app.task.service.ITransactionService;
import jakarta.transaction.Transactional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;

import java.util.Optional;

/**
 * @author Faizan Salamat
 */
@Service
public class TransactionService implements ITransactionService {

    @Autowired
    private TransactionRepository repository;
    @Autowired
    private RestClient.Builder builder;

    // This method handles save/update functionality
    @Transactional
    @Override
    public void saveTransaction(BankTransaction transaction) {
        // Check for duplicate based on unique fields before saving a new transaction
        Optional<BankTransaction> existingTransaction = repository.findByUniqueFields(
                transaction.getAccountNumber(),
                transaction.getTrxAmount(),
                transaction.getTrxDate(),
                transaction.getTrxTime(),
                transaction.getCustomerId()
        );

        if (existingTransaction.isPresent()) {
            System.out.println("Duplicate transaction found, skipping save.");
        } else {
            repository.save(transaction);
            System.out.println("Transaction saved successfully.");
        }
    }

    // Method to update an existing transaction
    @Transactional
    @Override
    public void updateTransaction(BankTransaction transaction) {
        if (transaction.getId() != null) {
            // Check if the transaction exists
            Optional<BankTransaction> existingTransaction = repository.findById(transaction.getId());
            if (existingTransaction.isPresent()) {
                // Update existing transaction with new values
                BankTransaction existing = existingTransaction.get()
                        .builder().
                        accountNumber(transaction.getAccountNumber())
                        .trxAmount(transaction.getTrxAmount())
                        .description(transaction.getDescription())
                        .trxDate(transaction.getTrxDate())
                        .trxTime(transaction.getTrxTime())
                        .customerId(transaction.getCustomerId()).build();

                // Save the updated transaction, leveraging optimistic locking
                repository.save(existing);
                System.out.println("Transaction updated successfully.");
            } else {
                System.out.println("Transaction not found for update.");
            }
        } else {
            System.out.println("Transaction ID is required for updating.");
        }
    }


    @Override
    public Page<BankTransaction> findAllTransactions(int page, int pageSize) {
        Pageable pageable = PageRequest.of(page, pageSize);
        return repository.findAll(pageable);
    }

    @Override
    public Page<BankTransaction> findAllTransactionsByCustomerId(int page, int pageSize, Long customerId) {
        Pageable pageable = PageRequest.of(page, pageSize);
        return repository.findByCustomerId(customerId, pageable);
    }

    @Override
    public BankTransaction findTransactionById(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new RuntimeException("Transaction not found"));
    }

    @Override
    public Page<BankTransaction> searchTransactions(Long customerId, String searchTerm, int page, int pageSize) {
        return repository.findTransactionsByCustomerIdOrAccountNumberOrDescription(customerId, searchTerm, PageRequest.of(page, pageSize));
    }
}
