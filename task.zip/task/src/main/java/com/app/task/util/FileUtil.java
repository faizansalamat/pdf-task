package com.app.task.util;

import com.app.task.model.BankTransaction;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.text.PDFTextStripper;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.IOException;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

/**
 * This Util reads the pdf file, cleans it and converts it into a Bank Transaction
 *
 * @author Faizan Salamat
 */
@Component
public class FileUtil {
    public static List<BankTransaction> parsePdf(String filePath) throws IOException {
        List<BankTransaction> transactions = new ArrayList<>();
        PDDocument document = PDDocument.load(new File(filePath));
        PDFTextStripper pdfStripper = new PDFTextStripper();

        String content = pdfStripper.getText(document);
        document.close();

        String[] lines = content.split("\n");
        boolean isHeader = true;
        for (String line : lines) {
            line = line.trim();
            if (line.isEmpty() || isHeader) {
                isHeader = false; // Skip the header line
                continue;
            }
            if (line.matches("\\d+\\|.*")) { // Match lines containing transaction data
                String[] parts = line.split("\\|");

                // Trim any trailing spaces or non-printable characters from each part
                for (int i = 0; i < parts.length; i++) {
                    parts[i] = parts[i].replaceAll("[^\\x20-\\x7E]", "").trim();
                }

                // Ensure parts array has enough length to avoid ArrayIndexOutOfBoundsException
                if (parts.length >= 6) {
                    BankTransaction transaction = BankTransaction.builder()
                            .accountNumber(parts[0])
                            .trxAmount(Double.valueOf(parts[1]))
                            .description(parts[2])
                            .trxDate(LocalDate.parse(parts[3]))
                            .trxTime(LocalTime.parse(parts[4]))
                            .customerId(Long.valueOf(parts[5]))
                            .build();
                    transactions.add(transaction);
                }
            }
        }
        return transactions;
    }
}
