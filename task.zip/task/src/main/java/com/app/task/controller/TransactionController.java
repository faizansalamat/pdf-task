package com.app.task.controller;

import com.app.task.model.BankTransaction;
import com.app.task.service.ITransactionService;
import com.app.task.util.FileUtil;
import io.swagger.v3.oas.annotations.Parameter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.util.List;

@RestController
@RequestMapping("/transactions")
@CrossOrigin(origins = "*")
public class TransactionController {

    @Autowired
    private ITransactionService service;

    @PostMapping("/upload")
    public ResponseEntity<String> uploadFile(@Parameter(description = "file", required = false) @RequestParam("file") MultipartFile file) {
        try {
            File tempFile = File.createTempFile("upload", null);
            file.transferTo(tempFile);
            List<BankTransaction> bankTransactions = FileUtil.parsePdf(tempFile.getAbsolutePath());
            bankTransactions.forEach(service::saveTransaction);
            tempFile.delete();
            return ResponseEntity.ok("File uploaded and processed successfully");
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body("Failed to process file: " + e.getMessage());
        }
    }

    @GetMapping("/all")
    public ResponseEntity<Page<BankTransaction>> getAllTransactions(
            @Parameter(description = "page number", required = true) @RequestParam(name = "page", defaultValue = "0") int page,
            @Parameter(description = "page size", required = true) @RequestParam(name = "size", defaultValue = "10") int size) {
        Page<BankTransaction> transactions = service.findAllTransactions(page, size);
        return ResponseEntity.ok(transactions);
    }

    @PostMapping("/save")
    public ResponseEntity<?> saveTransaction(
            @Parameter(description = "BankTransaction data to be saved", required = true) @RequestBody BankTransaction transaction) {
        service.saveTransaction(transaction);
        return ResponseEntity.ok("Transaction saved successfully");
    }

    @PutMapping("/update")
    public ResponseEntity<?> updateTransaction(
            @Parameter(description = "BankTransaction data to be updated", required = true) @RequestBody BankTransaction transaction) {
        service.updateTransaction(transaction);
        return ResponseEntity.ok("Transaction updated successfully");
    }

    @GetMapping("/search")
    public ResponseEntity<Page<BankTransaction>> searchTransactions(
            @Parameter(description = "Customer ID for searching transactions", required = false) @RequestParam(required = false) Long customerId,
            @Parameter(description = "Search term for account number or description", required = false) @RequestParam(required = false) String searchTerm,
            @Parameter(description = "page number", required = true) @RequestParam(name = "page", defaultValue = "0") int page,
            @Parameter(description = "page size", required = true) @RequestParam(name = "size", defaultValue = "10") int size) {
        return ResponseEntity.ok(service.searchTransactions(customerId, searchTerm, page, size));
    }

}
