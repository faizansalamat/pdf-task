package com.app.task.repository;

import com.app.task.model.BankTransaction;
import org.springframework.data.domain.Page;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.data.domain.Pageable;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface TransactionRepository extends JpaRepository<BankTransaction, Long> {
    Page<BankTransaction> findAll(Pageable pageable);
    Page<BankTransaction> findByCustomerId(Long customerId, Pageable pageable);

    @Query("SELECT t FROM BankTransaction t WHERE t.accountNumber = :accountNumber AND t.trxAmount = :trxAmount AND t.trxDate = :trxDate AND t.trxTime = :trxTime AND t.customerId = :customerId")
    Optional<BankTransaction> findByUniqueFields(
            @Param("accountNumber") String accountNumber,
            @Param("trxAmount") Double trxAmount,
            @Param("trxDate") LocalDate trxDate,
            @Param("trxTime") LocalTime trxTime,
            @Param("customerId") Long customerId
    );

    @Query("SELECT t FROM BankTransaction t WHERE " +
            "t.customerId = :customerId OR " +
            "LOWER(t.accountNumber) LIKE LOWER(CONCAT('%', :searchTerm, '%')) OR " +
            "LOWER(t.description) LIKE LOWER(CONCAT('%', :searchTerm, '%'))")
    Page<BankTransaction> findTransactionsByCustomerIdOrAccountNumberOrDescription(
            @Param("customerId") Long customerId,
            @Param("searchTerm") String searchTerm,
            Pageable pageable
    );

}
