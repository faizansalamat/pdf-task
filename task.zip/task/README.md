
## About This Project

This is a Spring Boot application designed to read transaction data from a PDF file and save it into a MySQL database. It has a scheduled job that runs every minute, so your transactions are processed regularly without any manual intervention.

## Swagger URL
- http://localhost:8080/swagger-ui/index.html#

## Patterns We’re Using

- **Service Layer Pattern** for business logic.
- **Builder Pattern** for object creation.
- **Repository Pattern** for data access abstraction.

## Code Structure

The code structure is designed using common design patterns and best practices:

- **Service Layer Pattern**: Handles business logic and acts as an interface between the controller and data access layer.
- **Repository Pattern**: Abstracts data access and provides a clean interface for database operations.
- **DTO (Data Transfer Object) Pattern**: Transfers data between layers without exposing internal entity classes.
- **Model (Entity) Pattern**: Represents the data in the application, often mapped to database tables.
- **Controller Layer**: Part of the MVC (Model-View-Controller) pattern, handling incoming HTTP requests and responding with appropriate data.

## What You Need to Get Started

- Java 11 or higher
- Maven or Gradle
- A MySQL database

## Getting It Up and Running

### Setting Up Your Database

Make sure your `application.properties` file has the correct database connection details:

```properties
spring.datasource.url=jdbc:mysql://localhost:3306/yourdatabase
spring.datasource.username=yourusername
spring.datasource.password=yourpassword
spring.jpa.hibernate.ddl-auto=update
```

### Steps to Run the App

1. Move into the project directory:
   ```bash
   cd transaction-service
   ```
2. Build it with Maven:
   ```bash
   mvn clean install
   ```
3. Run it:
   ```bash
   mvn spring-boot:run
   ```

## How It Works

- **Cron Job**: The `PdfCronJob` class runs every minute to read and process the PDF file.
- **Service Layer**: The `TransactionService` handles all the business logic like checking for duplicates, saving new transactions, and updating existing ones.
- **Entity Creation**: We use the Builder Pattern to create `Transaction` entities in a clean, readable way.
- **Database Storage**: The parsed data is stored in a MySQL database, with duplicate checks to avoid data redundancy.

## How to Use It

1. Place your PDF file in the `src/main/resources` directory.
2. Make sure your PDF structure follows the format: `ACCOUNT_NUMBER|TRX_AMOUNT|DESCRIPTION|TRX_DATE|TRX_TIME|CUSTOMER_ID`.
3. Start the app, and it will automatically process the PDF every minute.

